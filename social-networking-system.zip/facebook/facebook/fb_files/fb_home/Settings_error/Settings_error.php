<html>
<head>
</head>
<body>
<!-- erorr Designing -->
<div style="display:none; z-index:2;" id="error_design_format"> 

<!-- erorr background -->
<div style="position:fixed;left:30.4%;top:53.7%; height:6%; width:34.2%;  background:#FFEBE8; z-index:3; ">   </div>


<!-- erorr boder -->
<div style="position:fixed;left:30.4%; top:53.7%; height:1; width:34.2%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:30.3%; top:53.7%; height:6.1%; width:0.08%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:30.3%; top:59.7%; height:1; width:34.3%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:64.6%; top:53.7%; height:6.1%; width:0.05%; background-color:#DD3C10; z-index:3;"> </div>

</div>

<div style="position:fixed; left:38.6%; top:55.5%; display:none;  z-index:4;" id="Name_error"> The name contains invalid characters. </div>

<div style="position:fixed; left:39%; top:55.5%; display:none;  z-index:4;" id="full_Name_error"> You must provide your full name. </div>


<!-- erorr Designing -->
<div style="display:none; z-index:2;" id="error_design_format1"> 

<!-- erorr background -->
<div style="position:fixed;left:30.4%;top:61.7%; height:6%; width:34.2%;  background:#FFEBE8; z-index:3; ">   </div>


<!-- erorr boder -->
<div style="position:fixed;left:30.4%; top:61.7%; height:1; width:34.2%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:30.3%; top:61.7%; height:6.1%; width:0.08%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:30.3%; top:67.7%; height:1; width:34.3%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:64.6%; top:61.7%; height:6.1%; width:0.05%; background-color:#DD3C10; z-index:3;"> </div>

</div>

<div style="position:fixed; left:38.6%; top:63.5%; display:none;  z-index:4;" id="blank_error"> You must fill in all of the fields. </div>

<div style="position:fixed; left:35.5%; top:63.5%; display:none;  z-index:4;" id="not_match_error"> Your password do not match. Please try again. </div>

<div style="position:fixed; left:31%; top:63.5%; display:none;  z-index:4;" id="not_valid_error"> Your password must be at least 6 characters long. Please try another. </div>

</body>
</html>